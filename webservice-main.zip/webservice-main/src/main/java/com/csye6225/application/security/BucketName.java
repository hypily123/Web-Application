package com.csye6225.application.security;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;

@AllArgsConstructor
@Getter
public enum BucketName {

    
//    USER_IMAGE("spring-amazon-storage1");
//    private final String bucketName;
}
