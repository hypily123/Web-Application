//package com.csye6225.application.repository;
//
//import com.csye6225.application.model.EmailToken;
//import org.springframework.data.repository.CrudRepository;
//
//public interface TokenRepository extends CrudRepository<EmailToken, String> {
//}
