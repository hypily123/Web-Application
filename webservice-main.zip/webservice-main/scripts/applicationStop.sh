
ls
cd /home/ec2-user
sudo systemctl stop mywebservice.service
sudo systemctl daemon-reload
sudo rm -rf webservice
ls
pwd
sudo mkdir webservice
